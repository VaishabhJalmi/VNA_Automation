@echo off
python ms46122b_vna_gui.py
pause
