# MS46122B ShockLine VNA GUI — Version 2

This version combines the CSV plotter with direct MS46122B capture.

## What it does

### Four-panel measurement view
- Tr1: S11 Log Magnitude in dB
- Tr2: S22 Log Magnitude in dB
- Tr3: S21 Log Magnitude in dB
- Tr4: S11 or S22 Smith chart

### Direct VNA capture
The GUI communicates with ShockLine using raw TCP/IP SCPI.

Default:
- Host: `127.0.0.1`
- Port: `5001`

For a PC connected directly to the MS46122B/host running ShockLine, leave `127.0.0.1`.
If ShockLine is being controlled from another PC over the network, enter the host IP shown in the ShockLine Network Interface settings.

Click:
1. Start/open ShockLine.
2. Connect.
3. Capture VNA.

The program queries:
- channel 1 frequency array
- trace 1–4 S-parameter definitions
- trace 1–4 corrected real/imaginary S-parameter arrays

The trace mapping is detected from `:CALC1:PARn:DEF?`, so the program does not assume PAR1 must be S11.

## Install

Windows:

    py -m pip install -r requirements.txt

Run:

    py ms46122b_vna_gui.py

## Important

ShockLine must be running for the MS46122B socket interface.

The default TCP port documented for MS46122B is 5001. If your instrument has been configured with another port, enter that value.

The first direct-capture test should be done with the VNA connected and a normal sweep already configured. The application reads the existing corrected measurement; it does not perform or modify calibration.

## CSV

The viewer accepts the CSV structure shown in the supplied screenshot:

FREQ.GHZ,S11RE,S11IM,S21RE,S21IM,S12RE,S12IM,S22RE,S22IM

## Marker behavior

Six editable markers are provided to match the six markers visible in the ShockLine screenshot. Enter marker frequencies in GHz.

The GUI interpolates complex S-parameter data at the marker frequency and displays:
- S11 dB
- S22 dB
- S21 dB
- S11 magnitude
- S11 impedance at 50 ohm reference
- S22 impedance at 50 ohm reference

## Safety / measurement integrity

The Capture function reads the existing sweep. It does not change calibration, start/stop frequency, IF bandwidth, or limits.

Always verify the captured result against the ShockLine display before using it for production test decisions.

## Troubleshooting

If Connect fails:
- confirm ShockLine is open
- confirm the MS46122B is visible to ShockLine
- verify TCP port 5001
- try `127.0.0.1` if this GUI is running on the same Windows PC
- allow Python through Windows Firewall if prompted

If Capture fails with a data-length error:
- send the exact error message
- provide a screenshot of the ShockLine trace setup
- the parser can then be adapted to the exact firmware/data-format configuration.
