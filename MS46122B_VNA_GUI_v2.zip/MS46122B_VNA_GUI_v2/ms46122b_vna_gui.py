
import csv
import re
import socket
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.ticker import AutoMinorLocator


APP_TITLE = "MS46122B ShockLine VNA Test GUI"


def mag_db(z):
    z = np.asarray(z, dtype=complex)
    return 20.0 * np.log10(np.maximum(np.abs(z), 1e-15))


def smith_z(gamma, z0=50.0):
    gamma = np.asarray(gamma, dtype=complex)
    return z0 * (1 + gamma) / (1 - gamma)


def normalize_col(c):
    return re.sub(r"[^a-z0-9]", "", str(c).lower())


def load_anritsu_csv(filename):
    """
    Loads the CSV format shown in the supplied MS46122B screenshot.
    It ignores ShockLine metadata lines beginning with ! and finds a header
    containing FREQ + S11RE + S11IM.
    """
    raw = pd.read_csv(filename, comment="!", header=None, dtype=str,
                      engine="python")

    header_idx = None
    for i in range(len(raw)):
        joined = " ".join(str(x).strip() for x in raw.iloc[i].tolist()).upper()
        if "FREQ" in joined and "S11RE" in joined and "S11IM" in joined:
            header_idx = i
            break

    if header_idx is None:
        df = pd.read_csv(filename, dtype=str, engine="python")
    else:
        headers = [str(x).strip() for x in raw.iloc[header_idx].tolist()]
        df = raw.iloc[header_idx + 1:].copy()
        df.columns = headers

    df.columns = [str(c).strip() for c in df.columns]

    lookup = {normalize_col(c): c for c in df.columns}

    def col(*aliases):
        for a in aliases:
            if normalize_col(a) in lookup:
                return lookup[normalize_col(a)]
        return None

    fcol = col("FREQ.GHZ", "FREQ", "FREQUENCY", "FREQGHZ")
    names = {}
    for s in ("S11", "S21", "S12", "S22"):
        names[s + "RE"] = col(s + "RE")
        names[s + "IM"] = col(s + "IM")

    if fcol is None:
        raise ValueError("Frequency column not found.")
    missing = [k for k, v in names.items() if v is None]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing))

    out = pd.DataFrame()
    out["freq_ghz"] = pd.to_numeric(df[fcol], errors="coerce")
    for k, c in names.items():
        out[k] = pd.to_numeric(df[c], errors="coerce")

    out = out.dropna().sort_values("freq_ghz").reset_index(drop=True)

    # Defensive unit detection.
    mx = out["freq_ghz"].max()
    if mx > 1e5:
        out["freq_ghz"] /= 1e9
    elif mx > 1e3:
        out["freq_ghz"] /= 1e3

    for s in ("S11", "S21", "S12", "S22"):
        out[s] = out[s + "RE"].to_numpy() + 1j * out[s + "IM"].to_numpy()
    return out


def parse_ieee_block(resp):
    """
    Parse ShockLine IEEE-488.2 block data.
    The ShockLine programming manual documents FMA ASCII numeric arrays,
    FMB 64-bit real and FMC 32-bit real formats. This parser handles:
      * IEEE block + ASCII numeric data
      * plain ASCII numeric data
      * IEEE block + little/big endian float64/float32
    """
    if not resp:
        return np.array([], dtype=float)

    # Strip leading whitespace only for ASCII responses; do not strip binary
    # because binary payload may begin with arbitrary bytes.
    if resp.startswith(b"#"):
        if len(resp) < 2:
            return np.array([])
        nd = int(resp[1:2])
        if nd == 0:
            payload = resp[2:]
        else:
            nbytes = int(resp[2:2 + nd])
            start = 2 + nd
            payload = resp[start:start + nbytes]
    else:
        payload = resp.strip()

    # First try ASCII numeric parsing.
    try:
        text = payload.decode("ascii", errors="strict").strip()
        if text:
            vals = []
            for token in re.split(r"[,;\s]+", text.replace("\r", " ").replace("\n", " ")):
                if token:
                    vals.append(float(token))
            if vals:
                return np.asarray(vals, dtype=float)
    except (UnicodeDecodeError, ValueError):
        pass

    # Binary fallback. ShockLine default byte order is LSB (little endian).
    if len(payload) % 8 == 0:
        arr = np.frombuffer(payload, dtype="<f8")
        if np.isfinite(arr).sum() >= max(2, len(arr) // 2):
            return arr.copy()

    if len(payload) % 4 == 0:
        arr = np.frombuffer(payload, dtype="<f4")
        if np.isfinite(arr).sum() >= max(2, len(arr) // 2):
            return arr.astype(float)

    raise ValueError("Could not decode VNA data block.")


class ShockLineSocket:
    """Raw TCP/IP SCPI client for MS46122B TCP port 5001."""

    def __init__(self, host="127.0.0.1", port=5001, timeout=8.0):
        self.host = host
        self.port = int(port)
        self.timeout = float(timeout)
        self.sock = None
        self.lock = threading.Lock()

    def connect(self):
        self.close()
        s = socket.create_connection((self.host, self.port), timeout=self.timeout)
        s.settimeout(self.timeout)
        self.sock = s

    def close(self):
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
        self.sock = None

    def _read_message(self):
        # Read until newline for ordinary ASCII. For # block responses, first
        # read the header, then exactly the payload length, then consume LF.
        data = bytearray()

        # Read first byte so we know whether this is a block.
        while True:
            b = self.sock.recv(1)
            if not b:
                raise ConnectionError("VNA closed the connection.")
            data += b
            if b == b"#":
                break
            if b == b"\n":
                return bytes(data)

        # IEEE block header: # + number-of-digits + length digits
        nd_b = self.sock.recv(1)
        if not nd_b:
            raise ConnectionError("Incomplete IEEE block header.")
        data += nd_b
        nd = int(nd_b.decode("ascii"))

        if nd == 0:
            # Indefinite block; uncommon here. Read until newline.
            while True:
                b = self.sock.recv(4096)
                if not b:
                    break
                data += b
                if b.endswith(b"\n"):
                    break
            return bytes(data)

        length_bytes = b""
        while len(length_bytes) < nd:
            b = self.sock.recv(nd - len(length_bytes))
            if not b:
                raise ConnectionError("Incomplete IEEE block length.")
            length_bytes += b
        data += length_bytes
        n = int(length_bytes.decode("ascii"))

        payload = bytearray()
        while len(payload) < n:
            b = self.sock.recv(min(65536, n - len(payload)))
            if not b:
                raise ConnectionError("Incomplete IEEE block payload.")
            payload += b
        data += payload

        # Consume the normal LF terminator if present.
        self.sock.settimeout(0.05)
        try:
            tail = self.sock.recv(1)
            if tail:
                data += tail
        except socket.timeout:
            pass
        finally:
            self.sock.settimeout(self.timeout)

        return bytes(data)

    def write(self, command):
        if not self.sock:
            raise ConnectionError("Not connected to VNA.")
        msg = command.rstrip("\r\n") + "\n"
        with self.lock:
            self.sock.sendall(msg.encode("ascii"))

    def query(self, command):
        if not self.sock:
            raise ConnectionError("Not connected to VNA.")
        with self.lock:
            self.sock.sendall((command.rstrip("\r\n") + "\n").encode("ascii"))
            return self._read_message()

    def query_text(self, command):
        return self.query(command).decode("ascii", errors="replace").strip()

    def idn(self):
        return self.query_text("*IDN?")

    def capture(self):
        """
        Capture the four configured traces on channel 1. The trace mapping is
        queried rather than hard-coded, so PAR1..PAR4 can be in any order.
        """
        # ASCII numeric arrays are easiest to inspect/debug and are supported
        # by ShockLine for numerical array transfers.
        self.write(":FORM:DATA ASC")

        freq = parse_ieee_block(self.query(":SENS1:FREQ:DATA?"))

        traces = {}
        for t in range(1, 5):
            definition = self.query_text(f":CALC1:PAR{t}:DEF?")
            data = parse_ieee_block(self.query(f":CALC1:PAR{t}:DATA:SDAT?"))

            # SDAT is real/imaginary pairs.
            if len(data) % 2:
                raise ValueError(f"Trace {t} returned odd number of values.")
            if len(data) != 2 * len(freq):
                raise ValueError(
                    f"Trace {t} returned {len(data)} numbers; "
                    f"expected {2*len(freq)} for {len(freq)} sweep points."
                )

            values = data[0::2] + 1j * data[1::2]
            m = re.search(r"\b(S11|S12|S21|S22)\b", definition.upper())
            if m:
                traces[m.group(1)] = values

        missing = [s for s in ("S11", "S12", "S21", "S22") if s not in traces]
        if missing:
            raise ValueError(
                "Could not obtain " + ", ".join(missing) +
                ". Trace definitions returned: " +
                ", ".join(f"{k}" for k in traces)
            )

        return freq / 1e9, traces["S11"], traces["S21"], traces["S12"], traces["S22"]


class SmithChart:
    @staticmethod
    def draw(ax):
        ax.clear()
        ax.set_aspect("equal")
        ax.set_xlim(-1.08, 1.08)
        ax.set_ylim(-1.08, 1.08)
        ax.axis("off")

        th = np.linspace(0, 2*np.pi, 1200)
        ax.plot(np.cos(th), np.sin(th), linewidth=1.2)

        # Constant resistance circles in Gamma plane.
        for r in (0.2, 0.5, 1, 2, 5):
            center = r / (r + 1)
            radius = 1 / (r + 1)
            x = center + radius*np.cos(th)
            y = radius*np.sin(th)
            ax.plot(x, y, linewidth=0.45)

        # Constant reactance circles via z -> gamma.
        rr = np.logspace(-3, 3, 1500)
        for xv in (0.2, 0.5, 1, 2, 5):
            for sign in (1, -1):
                z = rr + 1j*sign*xv
                g = (z - 1) / (z + 1)
                ax.plot(g.real, g.imag, linewidth=0.45)

        ax.axhline(0, linewidth=0.4)
        ax.text(-0.02, 1.02, "+j", fontsize=8)
        ax.text(-0.02, -1.06, "-j", fontsize=8)
        ax.text(1.01, 0.02, "Γ", fontsize=9)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1550x960")
        self.minsize(1150, 750)

        self.vna = None
        self.data = None
        self.csv_path = None
        self.busy = False

        self.host = tk.StringVar(value="127.0.0.1")
        self.port = tk.StringVar(value="5001")
        self.timeout = tk.StringVar(value="8")

        self.markers = [tk.StringVar(value="") for _ in range(6)]
        self.specs = {
            "S11": tk.StringVar(value="-26"),
            "S22": tk.StringVar(value="-26"),
            "S21": tk.StringVar(value="-0.44"),
        }
        self.smith_param = tk.StringVar(value="S11")

        self._build_controls()
        self._build_plots()
        self._build_table()

    def _build_controls(self):
        bar = ttk.Frame(self, padding=6)
        bar.pack(fill=tk.X)

        ttk.Label(bar, text="VNA IP:").pack(side=tk.LEFT)
        ttk.Entry(bar, textvariable=self.host, width=15).pack(side=tk.LEFT, padx=3)
        ttk.Label(bar, text="Port:").pack(side=tk.LEFT)
        ttk.Entry(bar, textvariable=self.port, width=7).pack(side=tk.LEFT, padx=3)
        ttk.Button(bar, text="Connect", command=self.connect_vna).pack(side=tk.LEFT, padx=4)
        ttk.Button(bar, text="Disconnect", command=self.disconnect_vna).pack(side=tk.LEFT, padx=2)
        ttk.Button(bar, text="Capture VNA", command=self.capture_vna).pack(side=tk.LEFT, padx=8)
        ttk.Button(bar, text="Open CSV", command=self.open_csv).pack(side=tk.LEFT, padx=2)
        ttk.Button(bar, text="Save CSV", command=self.save_csv).pack(side=tk.LEFT, padx=2)
        ttk.Button(bar, text="Export Plot", command=self.export_plot).pack(side=tk.LEFT, padx=2)

        self.status = ttk.Label(bar, text="Disconnected")
        self.status.pack(side=tk.LEFT, padx=15)

        settings = ttk.LabelFrame(self, text="Trace / Marker Setup", padding=6)
        settings.pack(fill=tk.X, padx=6, pady=(0, 5))

        ttk.Label(settings, text="Markers GHz:").grid(row=0, column=0, sticky="w")
        for i, v in enumerate(self.markers):
            ttk.Label(settings, text=f"M{i+1}").grid(row=0, column=1+i*2)
            ttk.Entry(settings, textvariable=v, width=10).grid(row=0, column=2+i*2, padx=(2, 6))

        ttk.Label(settings, text="Limits dB:").grid(row=1, column=0, sticky="w", pady=(5, 0))
        for j, s in enumerate(("S11", "S22", "S21")):
            ttk.Label(settings, text=s).grid(row=1, column=1+j*2, pady=(5, 0))
            ttk.Entry(settings, textvariable=self.specs[s], width=10).grid(
                row=1, column=2+j*2, padx=(2, 6), pady=(5, 0)
            )

        ttk.Label(settings, text="Smith:").grid(row=1, column=8, pady=(5, 0))
        ttk.Combobox(
            settings, textvariable=self.smith_param,
            values=("S11", "S22"), state="readonly", width=8
        ).grid(row=1, column=9, pady=(5, 0))
        ttk.Button(settings, text="Update", command=self.update_plot).grid(
            row=1, column=10, padx=10, pady=(5, 0)
        )

    def _build_plots(self):
        self.panes = ttk.PanedWindow(self, orient=tk.VERTICAL)
        self.panes.pack(fill=tk.BOTH, expand=True, padx=6, pady=3)

        plot_frame = ttk.Frame(self.panes)
        table_frame = ttk.Frame(self.panes)
        self.panes.add(plot_frame, weight=5)
        self.panes.add(table_frame, weight=2)

        self.fig = plt.Figure(figsize=(12, 7), dpi=100)
        self.ax11 = self.fig.add_subplot(221)
        self.ax22 = self.fig.add_subplot(222)
        self.ax21 = self.fig.add_subplot(223)
        self.axsmith = self.fig.add_subplot(224)

        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def _build_table(self):
        cols = (
            "Marker", "Freq GHz", "S11 dB", "S22 dB", "S21 dB",
            "|S11|", "S11 Z ohm", "S22 Z ohm"
        )
        self.tree = ttk.Treeview(self.panes.panes()[-1] if False else self.canvas.get_tk_widget().master,
                                 columns=cols, show="headings")
        # Re-parenting a Treeview isn't possible; create a dedicated table frame.
        self.tree.destroy()

        table_frame = self.panes.nametowidget(self.panes.panes()[1])
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=9)
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=125, anchor="center")
        self.tree.column("Marker", width=70)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.configure(yscrollcommand=scroll.set)

    def set_status(self, text):
        self.status.config(text=text)
        self.update_idletasks()

    def connect_vna(self):
        if self.busy:
            return
        try:
            self.busy = True
            self.set_status("Connecting...")
            v = ShockLineSocket(self.host.get().strip(),
                                int(self.port.get()),
                                float(self.timeout.get()))
            v.connect()
            ident = v.idn()
            self.vna = v
            self.set_status("Connected: " + ident[:70])
        except Exception as e:
            self.vna = None
            self.set_status("Connection failed")
            messagebox.showerror(
                "MS46122B connection failed",
                "Could not connect.\n\n"
                f"Address: {self.host.get()}:{self.port.get()}\n\n"
                f"{e}\n\n"
                "Make sure ShockLine is running and TCP port 5001 is enabled."
            )
        finally:
            self.busy = False

    def disconnect_vna(self):
        if self.vna:
            self.vna.close()
        self.vna = None
        self.set_status("Disconnected")

    def capture_vna(self):
        if self.busy:
            return
        if not self.vna:
            messagebox.showwarning("Not connected", "Connect to the MS46122B first.")
            return

        self.busy = True
        self.set_status("Capturing sweep from MS46122B...")

        def worker():
            try:
                result = self.vna.capture()
                self.after(0, lambda: self._capture_done(result))
            except Exception as e:
                self.after(0, lambda: self._capture_error(e))

        threading.Thread(target=worker, daemon=True).start()

    def _capture_done(self, result):
        f, s11, s21, s12, s22 = result
        self.data = pd.DataFrame({
            "freq_ghz": f,
            "S11": s11, "S21": s21, "S12": s12, "S22": s22
        })
        self.csv_path = None
        self._auto_markers()
        self.update_plot()
        self.set_status(f"Captured {len(f):,} points | {f.min():.6g}–{f.max():.6g} GHz")
        self.busy = False

    def _capture_error(self, e):
        self.set_status("Capture failed")
        self.busy = False
        messagebox.showerror("VNA capture failed", str(e))

    def open_csv(self):
        path = filedialog.askopenfilename(
            filetypes=[("CSV", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            self.data = load_anritsu_csv(path)
            self.csv_path = path
            self._auto_markers()
            self.update_plot()
            self.set_status(
                f"Loaded {Path(path).name} | {len(self.data):,} points"
            )
        except Exception as e:
            messagebox.showerror("CSV error", str(e))

    def save_csv(self):
        if self.data is None:
            messagebox.showwarning("No data", "Capture or open a CSV first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv")]
        )
        if not path:
            return

        d = self.data
        out = pd.DataFrame({
            "FREQ.GHZ": d.freq_ghz,
            "S11RE": d.S11.apply(np.real),
            "S11IM": d.S11.apply(np.imag),
            "S21RE": d.S21.apply(np.real),
            "S21IM": d.S21.apply(np.imag),
            "S12RE": d.S12.apply(np.real),
            "S12IM": d.S12.apply(np.imag),
            "S22RE": d.S22.apply(np.real),
            "S22IM": d.S22.apply(np.imag),
        })
        out.to_csv(path, index=False, float_format="%.12E")
        self.set_status("Saved " + Path(path).name)

    def export_plot(self):
        if self.data is None:
            messagebox.showwarning("No data", "Load or capture data first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("PDF", "*.pdf")]
        )
        if path:
            self.fig.savefig(path, dpi=180, bbox_inches="tight")
            self.set_status("Exported " + Path(path).name)

    def _auto_markers(self):
        if self.data is None or len(self.data) < 2:
            return
        fmin = float(self.data.freq_ghz.min())
        fmax = float(self.data.freq_ghz.max())
        # Use the screenshot-like six-marker layout.
        for i, var in enumerate(self.markers):
            if not var.get().strip():
                var.set(f"{fmin + (fmax-fmin)*i/5:.6g}")

    def _interp(self, f, s):
        x = self.data.freq_ghz.to_numpy()
        z = np.asarray(s)
        return np.interp(f, x, z.real) + 1j*np.interp(f, x, z.imag)

    def _style(self, ax, title, ylabel):
        ax.clear()
        ax.set_title(title, loc="left", fontsize=10, fontweight="bold")
        ax.set_xlabel("Frequency (GHz)")
        ax.set_ylabel(ylabel)
        ax.grid(True, which="major", alpha=.35)
        ax.grid(True, which="minor", alpha=.15)
        ax.xaxis.set_minor_locator(AutoMinorLocator())
        ax.yaxis.set_minor_locator(AutoMinorLocator())
        ax.tick_params(labelsize=8)

    def _markers(self):
        ans = []
        for i, var in enumerate(self.markers):
            try:
                ans.append((i+1, float(var.get())))
            except ValueError:
                pass
        return ans

    def update_plot(self):
        if self.data is None:
            return

        d = self.data
        f = d.freq_ghz.to_numpy()
        s11 = d.S11.to_numpy()
        s22 = d.S22.to_numpy()
        s21 = d.S21.to_numpy()

        self._style(self.ax11, "Tr1  S11  Refl LogM", "dB")
        self._style(self.ax22, "Tr2  S22  Refl LogM", "dB")
        self._style(self.ax21, "Tr3  S21  Trans LogM", "dB")

        self.ax11.plot(f, mag_db(s11), linewidth=1.4, label="S11")
        self.ax22.plot(f, mag_db(s22), linewidth=1.4, label="S22")
        self.ax21.plot(f, mag_db(s21), linewidth=1.4, label="S21")

        for ax, key in ((self.ax11, "S11"), (self.ax22, "S22"), (self.ax21, "S21")):
            try:
                lim = float(self.specs[key].get())
                ax.axhline(lim, linestyle="--", linewidth=1.0,
                           label=f"Limit {lim:g} dB")
            except ValueError:
                pass
            ax.legend(fontsize=7, loc="best")

        rows = []
        for no, mf in self._markers():
            if mf < f.min() or mf > f.max():
                continue

            z11g = self._interp(mf, s11)
            z22g = self._interp(mf, s22)
            z21g = self._interp(mf, s21)

            for ax, val in (
                (self.ax11, mag_db(z11g)),
                (self.ax22, mag_db(z22g)),
                (self.ax21, mag_db(z21g)),
            ):
                ax.plot(mf, val, marker="o", markersize=5)
                ax.annotate(
                    f"M{no}\n{mf:.6g} GHz",
                    (mf, val), xytext=(0, 8),
                    textcoords="offset points", ha="center", fontsize=7
                )

            z11 = smith_z(z11g)
            z22 = smith_z(z22g)
            rows.append((no, mf, z11g, z22g, z21g, z11, z22))

        # Smith chart.
        SmithChart.draw(self.axsmith)
        selected = s11 if self.smith_param.get() == "S11" else s22
        self.axsmith.plot(selected.real, selected.imag, linewidth=1.5)
        self.axsmith.plot(selected.real, selected.imag, linewidth=0,
                          marker=".", markersize=2)
        self.axsmith.set_title(
            f"Tr4  {self.smith_param.get()}  Smith",
            loc="left", fontsize=10, fontweight="bold"
        )

        for no, mf, z11g, z22g, z21g, z11, z22 in rows:
            g = z11g if self.smith_param.get() == "S11" else z22g
            self.axsmith.plot(g.real, g.imag, marker="o", markersize=6)
            self.axsmith.annotate(f"M{no}", (g.real, g.imag),
                                  xytext=(5, 5), textcoords="offset points",
                                  fontsize=8)

        self.fig.tight_layout(pad=1.1)
        self.canvas.draw_idle()
        self._update_table(rows)

    def _update_table(self, rows):
        for item in self.tree.get_children():
            self.tree.delete(item)

        for no, mf, g11, g22, g21, z11, z22 in rows:
            def ztxt(z):
                return f"{z.real:.2f} {'+' if z.imag >= 0 else '-'} j{abs(z.imag):.2f}"

            self.tree.insert("", "end", values=(
                f"M{no}", f"{mf:.9g}",
                f"{mag_db(g11):.4f}",
                f"{mag_db(g22):.4f}",
                f"{mag_db(g21):.4f}",
                f"{abs(g11):.6f}",
                ztxt(z11), ztxt(z22)
            ))


if __name__ == "__main__":
    App().mainloop()
