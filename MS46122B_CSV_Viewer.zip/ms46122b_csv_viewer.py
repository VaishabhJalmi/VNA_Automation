import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.ticker import AutoMinorLocator


APP_TITLE = "Anritsu ShockLine MS46122B – CSV/S-Parameter Viewer"


def db(z):
    z = np.asarray(z, dtype=complex)
    return 20.0 * np.log10(np.maximum(np.abs(z), 1e-15))


def find_column(df, *names):
    normalized = {}
    for c in df.columns:
        key = re.sub(r"[^a-z0-9]", "", str(c).lower())
        normalized[key] = c
    for name in names:
        key = re.sub(r"[^a-z0-9]", "", name.lower())
        if key in normalized:
            return normalized[key]
    return None


def load_anritsu_csv(filename):
    # ShockLine exports shown by the user contain metadata lines beginning with !,
    # followed by one header line and numeric sweep data.
    raw = pd.read_csv(
        filename,
        comment="!",
        header=None,
        dtype=str,
        engine="python"
    )

    # Locate the row containing FREQ and S11RE/S11IM.
    header_idx = None
    for i in range(len(raw)):
        row = [str(x).strip() for x in raw.iloc[i].tolist()]
        joined = " ".join(row).upper()
        if "FREQ" in joined and "S11RE" in joined and "S11IM" in joined:
            header_idx = i
            break

    if header_idx is None:
        # Also support a normal CSV with headers on row 0.
        raw2 = pd.read_csv(filename, dtype=str, engine="python")
        raw2.columns = [str(c).strip() for c in raw2.columns]
        df = raw2
    else:
        headers = [str(x).strip() for x in raw.iloc[header_idx].tolist()]
        df = raw.iloc[header_idx + 1:].copy()
        df.columns = headers
        df = df.dropna(how="all")

    # Remove duplicate/blank column names.
    df.columns = [str(c).strip() for c in df.columns]
    df = df.loc[:, [c != "" and c.lower() != "nan" for c in df.columns]]

    fcol = find_column(df, "FREQ.GHZ", "FREQ", "FREQUENCY", "FREQGHZ")
    required = {
        "S11RE": find_column(df, "S11RE"),
        "S11IM": find_column(df, "S11IM"),
        "S21RE": find_column(df, "S21RE"),
        "S21IM": find_column(df, "S21IM"),
        "S12RE": find_column(df, "S12RE"),
        "S12IM": find_column(df, "S12IM"),
        "S22RE": find_column(df, "S22RE"),
        "S22IM": find_column(df, "S22IM"),
    }

    missing = [k for k, v in required.items() if v is None]
    if fcol is None:
        raise ValueError("Could not find the frequency column.")
    if missing:
        raise ValueError("Missing S-parameter columns: " + ", ".join(missing))

    out = pd.DataFrame()
    out["freq_ghz"] = pd.to_numeric(df[fcol], errors="coerce")

    for key, col in required.items():
        out[key] = pd.to_numeric(df[col], errors="coerce")

    out = out.dropna(subset=["freq_ghz"]).copy()

    # Remove accidental non-numeric rows.
    out = out.dropna(subset=list(required.keys()))

    # Some exports may have MHz/Hz despite the label. Detect obvious cases.
    maxf = out["freq_ghz"].max()
    if maxf > 1e5:
        out["freq_ghz"] /= 1e9
    elif maxf > 1e3:
        out["freq_ghz"] /= 1e3

    out = out.sort_values("freq_ghz").reset_index(drop=True)

    for s in ("S11", "S21", "S12", "S22"):
        out[s] = out[f"{s}RE"].to_numpy() + 1j * out[f"{s}IM"].to_numpy()

    return out


class SmithChart:
    """Minimal Smith chart drawn with matplotlib, no extra smithplot package required."""

    @staticmethod
    def draw(ax):
        ax.clear()
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlim(-1.08, 1.08)
        ax.set_ylim(-1.08, 1.08)
        ax.axis("off")

        theta = np.linspace(0, 2*np.pi, 1000)
        ax.plot(np.cos(theta), np.sin(theta), linewidth=1.2)

        # Constant resistance circles: r = 0, .2, .5, 1, 2, 5
        for r in [0.2, 0.5, 1, 2, 5]:
            center = r / (r + 1)
            radius = 1 / (r + 1)
            t = np.linspace(0, 2*np.pi, 600)
            x = center + radius*np.cos(t)
            y = radius*np.sin(t)
            mask = (x*x + y*y) <= 1.0005
            ax.plot(x[mask], y[mask], linewidth=0.55)

        # Constant reactance circles: x = ±0.2, ±0.5, ±1, ±2, ±5
        for xval in [0.2, 0.5, 1, 2, 5]:
            for sign in [1, -1]:
                x = sign * xval
                center_x = 1.0
                center_y = 1.0/x
                radius = abs(1.0/x)
                t = np.linspace(0, 2*np.pi, 900)
                gx = center_x + radius*np.cos(t)
                gy = center_y + radius*np.sin(t)
                # Gamma mapping for z = 1 + jx:
                # only retain points inside the unit Smith disk.
                mask = (gx*gx + gy*gy) <= 1.0005
                # The above circle construction is in impedance-normalized
                # coordinates, so use the standard direct mapping instead.
                z = 1j * x + 1.0
                # draw constant-x circle using gamma samples
                rvals = np.linspace(0.001, 100, 1200)
                zz = rvals + 1j*x
                gam = (zz - 1) / (zz + 1)
                ax.plot(gam.real, gam.imag, linewidth=0.55)

        ax.axhline(0, linewidth=0.45)
        ax.text(1.02, 0.02, "1", fontsize=8)
        ax.text(-1.03, 0.02, "-1", fontsize=8)


class VNAViewer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1500x930")
        self.minsize(1100, 700)

        self.data = None
        self.filename = ""
        self.marker_vars = [tk.StringVar(value="") for _ in range(6)]
        self.smith_param = tk.StringVar(value="S11")
        self.spec_vars = {
            "S11": tk.StringVar(value="-26"),
            "S22": tk.StringVar(value="-26"),
            "S21": tk.StringVar(value="-0.44"),
        }

        self._build_ui()
        self._build_figure()

    def _build_ui(self):
        top = ttk.Frame(self, padding=6)
        top.pack(side=tk.TOP, fill=tk.X)

        ttk.Button(top, text="Open CSV", command=self.open_csv).pack(side=tk.LEFT, padx=3)
        ttk.Button(top, text="Reload", command=self.reload).pack(side=tk.LEFT, padx=3)
        ttk.Button(top, text="Export PNG", command=self.export_png).pack(side=tk.LEFT, padx=3)

        ttk.Label(top, text="Smith:").pack(side=tk.LEFT, padx=(18, 3))
        ttk.Combobox(
            top, textvariable=self.smith_param,
            values=["S11", "S22"], state="readonly", width=7
        ).pack(side=tk.LEFT)
        ttk.Button(top, text="Update Plot", command=self.update_plots).pack(side=tk.LEFT, padx=8)

        self.status = ttk.Label(top, text="Open an Anritsu ShockLine CSV file.")
        self.status.pack(side=tk.LEFT, padx=15)

        controls = ttk.LabelFrame(self, text="Markers / Limits", padding=6)
        controls.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(0, 5))

        ttk.Label(controls, text="Marker frequency (GHz):").grid(row=0, column=0, padx=4)
        for i, var in enumerate(self.marker_vars, start=1):
            ttk.Label(controls, text=f"M{i}").grid(row=0, column=2*i-1, padx=(7, 2))
            e = ttk.Entry(controls, textvariable=var, width=11)
            e.grid(row=0, column=2*i, padx=(0, 5))
            e.bind("<Return>", lambda event: self.update_plots())

        ttk.Label(controls, text="Specs dB:").grid(row=1, column=0, padx=4, pady=(5, 0))
        for j, s in enumerate(("S11", "S22", "S21"), start=1):
            ttk.Label(controls, text=s).grid(row=1, column=2*j-1, padx=(7, 2), pady=(5, 0))
            ttk.Entry(controls, textvariable=self.spec_vars[s], width=11).grid(
                row=1, column=2*j, padx=(0, 5), pady=(5, 0)
            )
        ttk.Button(controls, text="Apply", command=self.update_plots).grid(
            row=1, column=13, padx=8, pady=(5, 0)
        )

        main = ttk.PanedWindow(self, orient=tk.VERTICAL)
        main.pack(fill=tk.BOTH, expand=True, padx=6, pady=3)

        plot_frame = ttk.Frame(main)
        table_frame = ttk.Frame(main)
        main.add(plot_frame, weight=5)
        main.add(table_frame, weight=2)

        self.plot_frame = plot_frame

        cols = ["Marker", "Freq (GHz)", "S11 (dB)", "S22 (dB)", "S21 (dB)",
                "S11 |Γ|", "S11 Z (Ω)", "S22 Z (Ω)"]
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=8)
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=120, anchor="center")
        self.tree.column("Marker", width=70)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        sb = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.configure(yscrollcommand=sb.set)

    def _build_figure(self):
        self.fig = plt.Figure(figsize=(12, 7), dpi=100)
        self.ax11 = self.fig.add_subplot(221)
        self.ax22 = self.fig.add_subplot(222)
        self.ax21 = self.fig.add_subplot(223)
        self.axsmith = self.fig.add_subplot(224)

        self.canvas = FigureCanvasTkAgg(self.fig, master=self.plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def open_csv(self):
        path = filedialog.askopenfilename(
            title="Open Anritsu ShockLine CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            self.data = load_anritsu_csv(path)
            self.filename = path
            self.status.config(
                text=f"{Path(path).name} | {len(self.data):,} points | "
                     f"{self.data.freq_ghz.min():.6g}–{self.data.freq_ghz.max():.6g} GHz"
            )
            self._auto_markers()
            self.update_plots()
        except Exception as e:
            messagebox.showerror("CSV error", str(e))

    def reload(self):
        if not self.filename:
            return
        try:
            self.data = load_anritsu_csv(self.filename)
            self.update_plots()
        except Exception as e:
            messagebox.showerror("Reload error", str(e))

    def _auto_markers(self):
        if self.data is None or len(self.data) == 0:
            return
        # The screenshot uses six markers distributed across the sweep.
        fmin = float(self.data.freq_ghz.min())
        fmax = float(self.data.freq_ghz.max())
        for i, var in enumerate(self.marker_vars):
            if not var.get().strip():
                f = fmin + (fmax - fmin) * i / 5
                var.set(f"{f:.6g}")

    def _style_axis(self, ax, title, ylabel):
        ax.clear()
        ax.set_title(title, loc="left", fontsize=10, fontweight="bold")
        ax.set_xlabel("Frequency (GHz)")
        ax.set_ylabel(ylabel)
        ax.grid(True, which="major", alpha=0.35)
        ax.grid(True, which="minor", alpha=0.15)
        ax.xaxis.set_minor_locator(AutoMinorLocator())
        ax.yaxis.set_minor_locator(AutoMinorLocator())
        ax.tick_params(labelsize=8)

    def _get_markers(self):
        vals = []
        for i, v in enumerate(self.marker_vars):
            try:
                f = float(v.get())
                vals.append((i + 1, f))
            except ValueError:
                pass
        return vals

    def _interp_complex(self, f, s):
        x = self.data.freq_ghz.to_numpy()
        return np.interp(f, x, s.real) + 1j*np.interp(f, x, s.imag)

    def update_plots(self):
        if self.data is None:
            return

        d = self.data
        f = d["freq_ghz"].to_numpy()
        s11, s22, s21 = d["S11"].to_numpy(), d["S22"].to_numpy(), d["S21"].to_numpy()

        self._style_axis(self.ax11, "Tr1  S11  Refl LogM", "dB")
        self._style_axis(self.ax22, "Tr2  S22  Refl LogM", "dB")
        self._style_axis(self.ax21, "Tr3  S21  Trans LogM", "dB")

        self.ax11.plot(f, db(s11), linewidth=1.4, label="S11")
        self.ax22.plot(f, db(s22), linewidth=1.4, label="S22")
        self.ax21.plot(f, db(s21), linewidth=1.4, label="S21")

        for ax, key in [(self.ax11, "S11"), (self.ax22, "S22"), (self.ax21, "S21")]:
            try:
                limit = float(self.spec_vars[key].get())
                ax.axhline(limit, linestyle="--", linewidth=1.0, label=f"Limit {limit:g} dB")
            except ValueError:
                pass
            ax.legend(fontsize=7, loc="best")

        markers = self._get_markers()
        marker_data = []
        for no, mf in markers:
            if mf < f.min() or mf > f.max():
                continue
            v11 = self._interp_complex(mf, s11)
            v22 = self._interp_complex(mf, s22)
            v21 = self._interp_complex(mf, s21)

            for ax, val in [(self.ax11, db(v11)), (self.ax22, db(v22)), (self.ax21, db(v21))]:
                ax.plot(mf, val, marker="o", markersize=5)
                ax.annotate(f"M{no}\n{mf:.6g} GHz", (mf, val),
                            textcoords="offset points", xytext=(0, 8),
                            ha="center", fontsize=7)

            z11 = 50 * (1 + v11) / (1 - v11)
            z22 = 50 * (1 + v22) / (1 - v22)
            marker_data.append((no, mf, v11, v22, v21, z11, z22))

        # Smith chart
        SmithChart.draw(self.axsmith)
        smith = s11 if self.smith_param.get() == "S11" else s22
        self.axsmith.plot(smith.real, smith.imag, linewidth=1.5)
        self.axsmith.plot(smith.real, smith.imag, linewidth=0, marker=".", markersize=2)
        self.axsmith.set_title(
            f"Tr4  {self.smith_param.get()}  Smith Chart",
            loc="left", fontsize=10, fontweight="bold"
        )

        for no, mf, v11, v22, v21, z11, z22 in marker_data:
            v = v11 if self.smith_param.get() == "S11" else v22
            self.axsmith.plot(v.real, v.imag, marker="o", markersize=6)
            self.axsmith.annotate(f"M{no}", (v.real, v.imag),
                                  xytext=(5, 5), textcoords="offset points", fontsize=8)

        self.fig.tight_layout(pad=1.2)
        self.canvas.draw_idle()
        self._update_table(marker_data)

    def _update_table(self, rows):
        for item in self.tree.get_children():
            self.tree.delete(item)

        for no, mf, v11, v22, v21, z11, z22 in rows:
            self.tree.insert("", "end", values=(
                f"M{no}", f"{mf:.9g}",
                f"{db(v11):.4f}", f"{db(v22):.4f}", f"{db(v21):.4f}",
                f"{abs(v11):.6f}",
                f"{z11.real:.2f} {'+' if z11.imag >= 0 else '-'} j{abs(z11.imag):.2f}",
                f"{z22.real:.2f} {'+' if z22.imag >= 0 else '-'} j{abs(z22.imag):.2f}",
            ))

    def export_png(self):
        if self.data is None:
            messagebox.showwarning("No data", "Open a CSV file first.")
            return
        path = filedialog.asksaveasfilename(
            title="Export plot",
            defaultextension=".png",
            filetypes=[("PNG image", "*.png"), ("PDF", "*.pdf")]
        )
        if not path:
            return
        self.fig.savefig(path, dpi=180, bbox_inches="tight")
        messagebox.showinfo("Export complete", f"Saved:\n{path}")


if __name__ == "__main__":
    app = VNAViewer()
    app.mainloop()
