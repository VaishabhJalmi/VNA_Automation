from __future__ import annotations

import csv
import math
import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pyvisa


@dataclass
class MarkerResult:
    channel: int
    trace: int
    marker: int
    frequency_hz: float | None
    y1: float | None
    y2: float | None
    parameter: str
    display_format: str
    enabled: bool = True
    error: str = ""


@dataclass
class TraceData:
    channel: int
    trace: int
    parameter: str
    display_format: str
    frequency_hz: np.ndarray
    real: np.ndarray
    imag: np.ndarray
    markers: list[MarkerResult] = field(default_factory=list)


@dataclass
class Acquisition:
    timestamp: str
    idn: str
    channel: int
    traces: list[TraceData]
    markers: list[MarkerResult]


class MS46122B:
    """
    Minimal ShockLine MS46122B driver.

    The driver deliberately uses the documented SCPI hierarchy:
      :CALC1:PARn:...
      :CALC1:DATA:SDAT?
      :SENS1:FREQ:DATA?

    It does not modify the user's calibration or measurement setup unless
    trigger_single_sweep() is explicitly requested.
    """

    def __init__(self, resource_name: str, timeout_ms: int = 30000):
        self.resource_name = resource_name
        self.timeout_ms = timeout_ms
        self.rm = None
        self.inst = None
        self.last_idn = ""

    @staticmethod
    def list_resources() -> tuple[str, ...]:
        rm = pyvisa.ResourceManager()
        try:
            return tuple(rm.list_resources())
        finally:
            rm.close()

    def connect(self) -> str:
        self.rm = pyvisa.ResourceManager()
        self.inst = self.rm.open_resource(self.resource_name)
        self.inst.timeout = self.timeout_ms
        self.inst.write_termination = "\n"
        self.inst.read_termination = "\n"

        # ASCII numeric output is intentionally used for the prototype.
        # This avoids binary endian/definite-block issues during initial deployment.
        self.write(":FORM:DATA ASCii")
        self.write(":FORM:BORD SWAPped")
        self.last_idn = self.query("*IDN?").strip()
        return self.last_idn

    def close(self) -> None:
        try:
            if self.inst is not None:
                self.inst.close()
        finally:
            self.inst = None
            if self.rm is not None:
                self.rm.close()
            self.rm = None

    def _check(self) -> None:
        if self.inst is None:
            raise RuntimeError("VNA is not connected.")

    def write(self, command: str) -> None:
        self._check()
        self.inst.write(command)

    def query(self, command: str) -> str:
        self._check()
        return self.inst.query(command)

    def query_ascii(self, command: str) -> list[float]:
        self._check()
        values = self.inst.query_ascii_values(command, converter="f")
        return [float(v) for v in values]

    def errors(self, max_items: int = 10) -> list[str]:
        """Read the SCPI error queue without raising on an empty queue."""
        out = []
        for _ in range(max_items):
            try:
                msg = self.query(":SYST:ERR?").strip()
            except Exception:
                break
            out.append(msg)
            if msg.startswith("0") or "No error" in msg:
                break
        return out

    def channel_start_stop(self, channel: int = 1) -> tuple[float, float]:
        start = float(self.query(f":SENS{channel}:FREQ:STAR?"))
        stop = float(self.query(f":SENS{channel}:FREQ:STOP?"))
        return start, stop

    def frequency_list(self, channel: int = 1) -> np.ndarray:
        """
        Read the actual frequency list. This is preferable to reconstructing
        it from start/stop/points because segmented/discrete sweeps may not be
        uniformly spaced.
        """
        values = self.query_ascii(f":SENS{channel}:FREQ:DATA?")
        return np.asarray(values, dtype=float)

    def trace_count(self, channel: int = 1) -> int:
        return int(float(self.query(f":CALC{channel}:PAR:COUN?")))

    def trace_parameter(self, channel: int, trace: int) -> str:
        return self.query(f":CALC{channel}:PAR{trace}:DEF?").strip()

    def trace_format(self, channel: int, trace: int) -> str:
        return self.query(f":CALC{channel}:PAR{trace}:FORM?").strip()

    def marker_enabled(self, channel: int, trace: int, marker: int) -> bool:
        return self.query(
            f":CALC{channel}:PAR{trace}:MARK{marker}?"
        ).strip() in {"1", "ON", "TRUE"}

    def marker(self, channel: int, trace: int, marker: int) -> MarkerResult:
        parameter = self.trace_parameter(channel, trace)
        fmt = self.trace_format(channel, trace)

        enabled = self.marker_enabled(channel, trace, marker)
        if not enabled:
            return MarkerResult(
                channel, trace, marker, None, None, None,
                parameter, fmt, enabled=False
            )

        x = float(self.query(f":CALC{channel}:PAR{trace}:MARK{marker}:X?"))
        y_text = self.query(f":CALC{channel}:PAR{trace}:MARK{marker}:Y?").strip()

        nums = parse_numeric_list(y_text)
        y1 = nums[0] if len(nums) >= 1 else None
        y2 = nums[1] if len(nums) >= 2 else None

        return MarkerResult(
            channel=channel,
            trace=trace,
            marker=marker,
            frequency_hz=x,
            y1=y1,
            y2=y2,
            parameter=parameter,
            display_format=fmt,
            enabled=True
        )

    def read_markers(
        self,
        channel: int = 1,
        trace: int = 1,
        marker_count: int = 13
    ) -> list[MarkerResult]:
        results = []
        for m in range(1, marker_count + 1):
            try:
                result = self.marker(channel, trace, m)
                if result.enabled:
                    results.append(result)
            except Exception as exc:
                # A bad marker query should not stop acquisition of the other markers.
                results.append(
                    MarkerResult(
                        channel, trace, m, None, None, None,
                        self.safe_trace_parameter(channel, trace),
                        self.safe_trace_format(channel, trace),
                        enabled=False,
                        error=str(exc)
                    )
                )
        return results

    def safe_trace_parameter(self, channel: int, trace: int) -> str:
        try:
            return self.trace_parameter(channel, trace)
        except Exception:
            return "UNKNOWN"

    def safe_trace_format(self, channel: int, trace: int) -> str:
        try:
            return self.trace_format(channel, trace)
        except Exception:
            return "UNKNOWN"

    def select_trace(self, channel: int, trace: int) -> None:
        self.write(f":CALC{channel}:PAR{trace}:SEL")

    def complex_trace(
        self,
        channel: int,
        trace: int,
        frequency_hz: np.ndarray | None = None
    ) -> TraceData:
        """
        Select a trace and retrieve real/imaginary S-parameter data.

        ShockLine documents DATA:SDAT? as real/imaginary S-parameter data
        for the active trace.
        """
        parameter = self.trace_parameter(channel, trace)
        fmt = self.trace_format(channel, trace)
        self.select_trace(channel, trace)

        values = self.query_ascii(f":CALC{channel}:DATA:SDAT?")
        arr = np.asarray(values, dtype=float)

        if arr.size % 2:
            raise RuntimeError(
                f"Unexpected SDAT length {arr.size} for trace {trace}. "
                "Expected an even number of real/imaginary values."
            )

        real = arr[0::2]
        imag = arr[1::2]

        if frequency_hz is None:
            frequency_hz = self.frequency_list(channel)

        if len(frequency_hz) != len(real):
            raise RuntimeError(
                f"Frequency/data length mismatch for trace {trace}: "
                f"{len(frequency_hz)} frequencies vs {len(real)} complex points."
            )

        return TraceData(
            channel=channel,
            trace=trace,
            parameter=parameter,
            display_format=fmt,
            frequency_hz=np.asarray(frequency_hz),
            real=real,
            imag=imag
        )

    def trigger_single_sweep(
        self,
        channel: int = 1,
        command: str = ":INIT1:IMM;*WAI",
        restore_continuous: bool = True
    ) -> None:
        """
        Optional single-sweep trigger.

        This is intentionally explicit because trigger behavior can depend on
        the VNA's current trigger configuration.
        """
        previous = None
        try:
            previous = self.query(":INIT:CONT?").strip()
        except Exception:
            pass

        try:
            if previous in {"1", "ON"}:
                self.write(":INIT:CONT OFF")
                time.sleep(0.05)
            self.write(command)
        finally:
            if restore_continuous and previous in {"1", "ON"}:
                try:
                    self.write(":INIT:CONT ON")
                except Exception:
                    pass

    def acquire(
        self,
        channel: int = 1,
        max_traces: int = 4,
        marker_count: int = 13,
        trigger: bool = False,
        trigger_command: str = ":INIT1:IMM;*WAI",
        restore_continuous: bool = True
    ) -> Acquisition:
        if trigger:
            self.trigger_single_sweep(
                channel=channel,
                command=trigger_command,
                restore_continuous=restore_continuous
            )

        frequency = self.frequency_list(channel)
        count = min(self.trace_count(channel), max_traces)

        traces = []
        markers = []

        for trace in range(1, count + 1):
            td = self.complex_trace(channel, trace, frequency)
            td.markers = self.read_markers(channel, trace, marker_count)
            traces.append(td)
            markers.extend(td.markers)

        return Acquisition(
            timestamp=datetime.now().isoformat(timespec="seconds"),
            idn=self.last_idn or self.query("*IDN?").strip(),
            channel=channel,
            traces=traces,
            markers=markers
        )


def parse_numeric_list(text: str) -> list[float]:
    """
    Parse comma-separated SCPI numeric output.
    Handles values such as:
      -1.23
      1.0E+9,-0.5
    """
    text = text.strip()
    if not text:
        return []

    parts = [p.strip() for p in text.split(",")]
    result = []
    for p in parts:
        try:
            result.append(float(p))
        except ValueError:
            # Fall back to extracting scientific notation from a decorated string.
            match = re.search(
                r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?",
                p
            )
            if match:
                result.append(float(match.group(0)))
    return result


def _fmt_frequency_hz(hz: float) -> str:
    if abs(hz) >= 1e9:
        return f"{hz / 1e9:.12g} GHz"
    if abs(hz) >= 1e6:
        return f"{hz / 1e6:.12g} MHz"
    if abs(hz) >= 1e3:
        return f"{hz / 1e3:.12g} kHz"
    return f"{hz:.12g} Hz"


def _safe_filename(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text)


def export_csv(acq: Acquisition, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "timestamp", "channel", "trace", "marker", "frequency_hz",
            "y1", "y2", "parameter", "display_format", "enabled", "error"
        ])

        for m in acq.markers:
            writer.writerow([
                acq.timestamp, m.channel, m.trace, m.marker,
                m.frequency_hz, m.y1, m.y2,
                m.parameter, m.display_format, m.enabled, m.error
            ])

    return path


def export_excel(acq: Acquisition, path: str | Path) -> Path:
    import pandas as pd

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    summary = pd.DataFrame([{
        "Timestamp": acq.timestamp,
        "VNA": acq.idn,
        "Channel": acq.channel,
        "Trace count": len(acq.traces)
    }])

    marker_rows = []
    for m in acq.markers:
        marker_rows.append({
            "Trace": m.trace,
            "Marker": m.marker,
            "Frequency_Hz": m.frequency_hz,
            "Y1": m.y1,
            "Y2": m.y2,
            "Parameter": m.parameter,
            "Display_Format": m.display_format,
            "Enabled": m.enabled,
            "Error": m.error
        })

    marker_df = pd.DataFrame(marker_rows)

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Summary", index=False)
        marker_df.to_excel(writer, sheet_name="Markers", index=False)

        for td in acq.traces:
            df = pd.DataFrame({
                "Frequency_Hz": td.frequency_hz,
                "Real": td.real,
                "Imag": td.imag,
                "Magnitude": np.abs(td.real + 1j * td.imag),
                "Magnitude_dB": 20 * np.log10(
                    np.maximum(np.abs(td.real + 1j * td.imag), 1e-300)
                ),
                "Phase_deg": np.angle(td.real + 1j * td.imag, deg=True)
            })
            sheet = f"Tr{td.trace}_{_safe_filename(td.parameter)[:20]}"
            df.to_excel(writer, sheet_name=sheet[:31], index=False)

    return path


def _trace_by_parameter(acq: Acquisition, parameter: str) -> TraceData | None:
    for td in acq.traces:
        if td.parameter.upper().strip() == parameter.upper():
            return td
    return None


def export_s2p(acq: Acquisition, path: str | Path, z0: float = 50.0) -> Path:
    """
    Export S2P in RI format.

    S11, S21, S22 are taken from the available configured traces.
    S12 is exported as NaN if no S12 trace exists.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    s11 = _trace_by_parameter(acq, "S11")
    s12 = _trace_by_parameter(acq, "S12")
    s21 = _trace_by_parameter(acq, "S21")
    s22 = _trace_by_parameter(acq, "S22")

    available = [x for x in (s11, s12, s21, s22) if x is not None]
    if not available:
        raise RuntimeError("No S-parameter traces are available.")

    base = available[0]
    freq = base.frequency_hz

    def interp_complex(td: TraceData | None) -> np.ndarray:
        if td is None:
            return np.full(len(freq), np.nan + 1j * np.nan, dtype=complex)
        if len(td.frequency_hz) == len(freq) and np.allclose(td.frequency_hz, freq):
            return td.real + 1j * td.imag
        # Interpolate real and imaginary parts onto the base frequency grid.
        r = np.interp(freq, td.frequency_hz, td.real)
        i = np.interp(freq, td.frequency_hz, td.imag)
        return r + 1j * i

    vals = {
        "S11": interp_complex(s11),
        "S12": interp_complex(s12),
        "S21": interp_complex(s21),
        "S22": interp_complex(s22)
    }

    with path.open("w", encoding="ascii", newline="\n") as f:
        f.write("! Generated by MS46122B Automation Prototype\n")
        f.write(f"! VNA: {acq.idn}\n")
        f.write(f"! Timestamp: {acq.timestamp}\n")
        f.write(f"# Hz S RI R {z0:g}\n")

        for idx, hz in enumerate(freq):
            row = [hz]
            for p in ("S11", "S21", "S12", "S22"):
                c = vals[p][idx]
                row.extend([c.real, c.imag])
            f.write(" ".join(
                "nan" if isinstance(x, float) and math.isnan(x)
                else f"{x:.12e}"
                for x in row
            ) + "\n")

    return path
