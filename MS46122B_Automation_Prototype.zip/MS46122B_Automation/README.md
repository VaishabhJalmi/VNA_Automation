# Anritsu MS46122B Automation Prototype

A Python/PySide6 prototype for automating an Anritsu ShockLine MS46122B.

## What it does

- Detects VISA resources
- Connects to the MS46122B over USB/VISA
- Reads `*IDN?`
- Reads the current Channel 1 trace configuration
- Reads enabled markers M1-M13 for traces 1-4
- Reads complex S-parameter data from each configured trace
- Reads the channel frequency list
- Displays marker results in a GUI
- Exports marker data to CSV
- Exports a multi-sheet Excel report
- Exports a 2-port Touchstone `.s2p` file
- Includes a mock mode so the GUI can be tested without a VNA

## Important

This program intentionally does NOT change your existing calibration, frequency range,
IF bandwidth, power, averaging, limits, or trace setup.

The first version is an acquisition/readout application. This is safer for an existing
production/R&D VNA setup.

## Windows installation

1. Install Python 3.11 or newer.
2. Install the Anritsu ShockLine software/USB driver.
3. If you already have NI-VISA installed, keep using it.
4. Open Command Prompt in this folder:

```text
python -m pip install -r requirements.txt
```

5. Run:

```text
python app.py
```

## First test

Use the `Refresh VISA` button.

You should see something similar to:

```text
USB0::...::INSTR
```

Select it and click `Connect`.

The status bar should show the MS46122B identification.

## Recommended first acquisition

Do NOT enable the "Trigger single sweep" option on your first test.

Instead:

1. Keep the VNA running your existing measurement setup.
2. Connect the DUT normally.
3. Let the VNA finish its sweep.
4. Click `Acquire current sweep`.
5. Confirm that Tr1-Tr4 and the markers appear.
6. Export CSV/Excel.

After that is working, test single-sweep triggering.

## Marker handling

The application checks the marker state before reading each marker. It therefore does
not assume that all M1-M12 are enabled.

For each enabled marker it reads:

- trace number
- marker number
- frequency/location
- marker response Y1/Y2
- measurement parameter
- display format

For Smith Chart markers, Y can contain two values. The application preserves both values
instead of guessing which one is resistance/reactance.

## Complete trace data

The application uses:

```text
:CALC1:PARn:SEL
:CALC1:DATA:SDAT?
```

to retrieve corrected complex S-parameter data from the selected trace.

The frequency array is read using:

```text
:SENS1:FREQ:DATA?
```

The MS46122B/2-port ShockLine programming manual documents these command families.

## S2P export

The `.s2p` export uses:

- S11 from the trace configured as S11
- S21 from the trace configured as S21
- S12 and S22 are included if matching traces are available

If your setup only has S11/S22/S21, the generated file will contain blank/NaN S12 values.
For a normal 2-port DUT test, add an S12 trace to the VNA if you need complete S2P data.

## Troubleshooting

### No VISA resource

Try:

```python
import pyvisa
rm = pyvisa.ResourceManager()
print(rm.list_resources())
```

If the VNA is not listed:

- verify the ShockLine software is installed
- verify the USB cable
- verify Windows Device Manager sees the VNA
- check whether NI-VISA/Anritsu VISA is installed
- close software that has exclusive control of the instrument if necessary

### Query timeout

Try increasing the timeout in `config.json`.

For large sweeps, 30-60 seconds is reasonable.

### Trace data query fails

The code logs the exact SCPI command. Check the VNA error queue from the GUI's
SCPI console/test area or compare the command with the installed ShockLine programming
manual. Firmware/software revisions can add command differences.

## Productionization ideas

Before using this as a production tester, add:

- DUT barcode/serial input
- operator login
- company-specific limits
- calibration validity check
- automatic single-sweep trigger
- PASS/FAIL logic
- SQLite database
- test recipe selection
- audit trail
- automatic report naming
- instrument serial number capture
- calibration file/setup identification
- watchdog/reconnect handling
