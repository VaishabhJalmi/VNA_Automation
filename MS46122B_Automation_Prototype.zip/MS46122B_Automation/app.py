from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path
from datetime import datetime

import numpy as np
from PySide6.QtCore import QObject, QThread, Signal
from PySide6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QMainWindow, QMessageBox, QPlainTextEdit,
    QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget, QCheckBox
)

from ms46122b import (
    Acquisition,
    MS46122B,
    export_csv,
    export_excel,
    export_s2p,
)


APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "config.json"


def load_config():
    defaults = {
        "channel": 1,
        "marker_count": 13,
        "visa_timeout_ms": 30000,
        "query_delay_s": 0.0,
        "trigger_before_acquire": False,
        "trigger_command": ":INIT1:IMM;*WAI",
        "restore_continuous_after_trigger": True,
        "export_directory": "results",
    }

    if CONFIG_PATH.exists():
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            defaults.update(data)
        except Exception:
            pass

    return defaults


class Worker(QObject):
    finished = Signal(object)
    error = Signal(str)
    log = Signal(str)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def run(self):
        try:
            result = self.fn()
            self.finished.emit(result)
        except Exception:
            self.error.emit(traceback.format_exc())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.cfg = load_config()
        self.vna: MS46122B | None = None
        self.acquisition: Acquisition | None = None

        self.setWindowTitle("Anritsu MS46122B Automation Prototype")
        self.resize(1250, 800)

        self._build_ui()
        self.refresh_resources()

    def _build_ui(self):
        central = QWidget()
        root = QVBoxLayout(central)

        # Connection group
        conn = QGroupBox("VNA Connection")
        grid = QGridLayout(conn)

        self.resource_combo = QComboBox()
        self.refresh_button = QPushButton("Refresh VISA")
        self.connect_button = QPushButton("Connect")
        self.disconnect_button = QPushButton("Disconnect")
        self.idn_label = QLabel("Not connected")

        self.refresh_button.clicked.connect(self.refresh_resources)
        self.connect_button.clicked.connect(self.connect_vna)
        self.disconnect_button.clicked.connect(self.disconnect_vna)

        grid.addWidget(QLabel("VISA resource:"), 0, 0)
        grid.addWidget(self.resource_combo, 0, 1)
        grid.addWidget(self.refresh_button, 0, 2)
        grid.addWidget(self.connect_button, 0, 3)
        grid.addWidget(self.disconnect_button, 0, 4)
        grid.addWidget(QLabel("IDN:"), 1, 0)
        grid.addWidget(self.idn_label, 1, 1, 1, 4)

        root.addWidget(conn)

        # Acquisition controls
        acq = QGroupBox("Acquisition")
        ag = QGridLayout(acq)

        self.channel_spin = QSpinBox()
        self.channel_spin.setRange(1, 16)
        self.channel_spin.setValue(int(self.cfg["channel"]))

        self.marker_spin = QSpinBox()
        self.marker_spin.setRange(1, 13)
        self.marker_spin.setValue(int(self.cfg["marker_count"]))

        self.trigger_check = QCheckBox("Trigger single sweep before reading")
        self.trigger_check.setChecked(bool(self.cfg["trigger_before_acquire"]))

        self.acquire_button = QPushButton("Acquire current sweep")
        self.acquire_button.clicked.connect(self.acquire)

        self.export_csv_button = QPushButton("Export CSV")
        self.export_excel_button = QPushButton("Export Excel")
        self.export_s2p_button = QPushButton("Export S2P")

        self.export_csv_button.clicked.connect(self.save_csv)
        self.export_excel_button.clicked.connect(self.save_excel)
        self.export_s2p_button.clicked.connect(self.save_s2p)

        ag.addWidget(QLabel("Channel:"), 0, 0)
        ag.addWidget(self.channel_spin, 0, 1)
        ag.addWidget(QLabel("Markers to check:"), 0, 2)
        ag.addWidget(self.marker_spin, 0, 3)
        ag.addWidget(self.trigger_check, 0, 4)
        ag.addWidget(self.acquire_button, 0, 5)
        ag.addWidget(self.export_csv_button, 1, 4)
        ag.addWidget(self.export_excel_button, 1, 5)
        ag.addWidget(self.export_s2p_button, 1, 3)

        root.addWidget(acq)

        # Results
        results_group = QGroupBox("Marker Results")
        rg = QVBoxLayout(results_group)

        self.marker_table = QTableWidget(0, 10)
        self.marker_table.setHorizontalHeaderLabels([
            "Trace", "Marker", "Frequency (Hz)", "Y1", "Y2",
            "Parameter", "Format", "Enabled", "Result", "Error"
        ])
        self.marker_table.horizontalHeader().setStretchLastSection(True)
        rg.addWidget(self.marker_table)

        root.addWidget(results_group, 1)

        # Log
        log_group = QGroupBox("SCPI / Application Log")
        lg = QVBoxLayout(log_group)
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        lg.addWidget(self.log_box)
        root.addWidget(log_group)

        self.setCentralWidget(central)
        self.statusBar().showMessage("Ready")

        self._set_connected(False)

    def log(self, text: str):
        self.log_box.appendPlainText(
            f"[{datetime.now().strftime('%H:%M:%S')}] {text}"
        )

    def refresh_resources(self):
        self.resource_combo.clear()

        try:
            resources = MS46122B.list_resources()
            for r in resources:
                self.resource_combo.addItem(r)

            if not resources:
                self.log("No VISA resources found.")
            else:
                self.log("VISA resources: " + ", ".join(resources))

        except Exception as exc:
            self.log(f"VISA resource enumeration failed: {exc}")

    def _set_connected(self, connected: bool):
        self.connect_button.setEnabled(not connected)
        self.disconnect_button.setEnabled(connected)
        self.acquire_button.setEnabled(connected)
        self.export_csv_button.setEnabled(self.acquisition is not None)
        self.export_excel_button.setEnabled(self.acquisition is not None)
        self.export_s2p_button.setEnabled(self.acquisition is not None)

    def connect_vna(self):
        resource = self.resource_combo.currentText().strip()
        if not resource:
            QMessageBox.warning(self, "No VISA resource", "Select a VISA resource.")
            return

        self.log(f"Connecting to {resource} ...")
        try:
            self.vna = MS46122B(
                resource,
                timeout_ms=int(self.cfg["visa_timeout_ms"])
            )
            idn = self.vna.connect()
            self.idn_label.setText(idn)
            self.log(f"Connected: {idn}")
            self._set_connected(True)
            self.statusBar().showMessage("Connected")
        except Exception as exc:
            self.vna = None
            self.log(traceback.format_exc())
            QMessageBox.critical(self, "Connection failed", str(exc))
            self._set_connected(False)

    def disconnect_vna(self):
        if self.vna:
            try:
                self.vna.close()
            except Exception:
                pass

        self.vna = None
        self.idn_label.setText("Not connected")
        self._set_connected(False)
        self.statusBar().showMessage("Disconnected")
        self.log("Disconnected.")

    def acquire(self):
        if not self.vna:
            return

        channel = int(self.channel_spin.value())
        marker_count = int(self.marker_spin.value())
        trigger = self.trigger_check.isChecked()

        self.acquire_button.setEnabled(False)
        self.statusBar().showMessage("Acquiring...")

        def task():
            self.log(f"Acquisition started: CH{channel}, markers 1-{marker_count}")
            if trigger:
                self.log("Trigger requested.")
            acq = self.vna.acquire(
                channel=channel,
                max_traces=4,
                marker_count=marker_count,
                trigger=trigger,
                trigger_command=self.cfg["trigger_command"],
                restore_continuous=bool(
                    self.cfg["restore_continuous_after_trigger"]
                )
            )
            return acq

        thread = QThread()
        worker = Worker(task)
        worker.moveToThread(thread)

        thread.started.connect(worker.run)
        worker.finished.connect(self.acquisition_finished)
        worker.error.connect(self.acquisition_error)

        worker.finished.connect(thread.quit)
        worker.error.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        worker.error.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)

        self._thread = thread
        self._worker = worker
        thread.start()

    def acquisition_finished(self, acq: Acquisition):
        self.acquisition = acq
        self.display_acquisition(acq)

        self.statusBar().showMessage(
            f"Acquired {len(acq.traces)} traces / {len(acq.markers)} enabled markers"
        )
        self.log(
            f"Acquisition complete: {len(acq.traces)} traces, "
            f"{len(acq.markers)} enabled markers."
        )

        if self.vna:
            try:
                errors = self.vna.errors()
                if errors:
                    self.log("VNA error queue: " + " | ".join(errors))
            except Exception:
                pass

        self._set_connected(True)

    def acquisition_error(self, details: str):
        self.statusBar().showMessage("Acquisition failed")
        self.log(details)
        QMessageBox.critical(self, "Acquisition failed", details)
        self._set_connected(self.vna is not None)

    def display_acquisition(self, acq: Acquisition):
        self.marker_table.setRowCount(0)

        for m in acq.markers:
            row = self.marker_table.rowCount()
            self.marker_table.insertRow(row)

            values = [
                m.trace,
                m.marker,
                "" if m.frequency_hz is None else f"{m.frequency_hz:.12g}",
                "" if m.y1 is None else f"{m.y1:.12g}",
                "" if m.y2 is None else f"{m.y2:.12g}",
                m.parameter,
                m.display_format,
                "ON" if m.enabled else "OFF",
                "READ" if not m.error else "ERROR",
                m.error
            ]

            for col, value in enumerate(values):
                self.marker_table.setItem(
                    row, col, QTableWidgetItem(str(value))
                )

        self.marker_table.resizeColumnsToContents()

    def _default_result_dir(self) -> Path:
        d = APP_DIR / self.cfg["export_directory"]
        d.mkdir(parents=True, exist_ok=True)
        return d

    def save_csv(self):
        if not self.acquisition:
            return

        default = self._default_result_dir() / "markers.csv"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save CSV", str(default), "CSV (*.csv)"
        )
        if not path:
            return

        try:
            out = export_csv(self.acquisition, path)
            self.log(f"CSV saved: {out}")
        except Exception as exc:
            QMessageBox.critical(self, "CSV export failed", str(exc))

    def save_excel(self):
        if not self.acquisition:
            return

        default = self._default_result_dir() / "MS46122B_result.xlsx"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Excel", str(default), "Excel (*.xlsx)"
        )
        if not path:
            return

        try:
            out = export_excel(self.acquisition, path)
            self.log(f"Excel saved: {out}")
        except Exception as exc:
            QMessageBox.critical(self, "Excel export failed", str(exc))

    def save_s2p(self):
        if not self.acquisition:
            return

        default = self._default_result_dir() / "DUT.s2p"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Touchstone", str(default), "Touchstone (*.s2p)"
        )
        if not path:
            return

        try:
            out = export_s2p(self.acquisition, path)
            self.log(f"S2P saved: {out}")
        except Exception as exc:
            QMessageBox.critical(self, "S2P export failed", str(exc))

    def closeEvent(self, event):
        self.disconnect_vna()
        event.accept()


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
